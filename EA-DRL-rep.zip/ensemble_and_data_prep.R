



source("../packages.R")
source("../ensemble_prep_fn.R")

ts=read.csv('') #call ur data file or load the RData file in the repository it contains the embedded data

dataset=data_lag_prep(ts,1,5) #embedd your data


#split ts into train and test for regression and time series analysis models

train.ts=data.frame(dataset[1:2000,1])
test.ts=data.frame(dataset[2001:2688,1])

names(train.ts)=names(test.ts)="target"

train.reg=dataset[1:2000,]
test.reg=dataset[2001:2688,]



data.train=train.reg
data.test=test.reg
n=nrow(data.train)
val.length=10
H=10
data.val=data.train[((n-val.length+1):n), ]
data.train.n=data.train[(1:(n-val.length)), ]
formula=target~.
models=train.models(data.train.n, formula,ker=c("rbfdot" ,"polydot" ,"vanilladot", "laplacedot"))


predictions.table=predict.models(models,data.test,formula, per.arima,ker=c("rbfdot" ,"polydot" ,"vanilladot", "laplacedot"))


sapply(1:ncol(predictions.table), function(x) rmse(predictions.table[,1],predictions.table[,x]))


