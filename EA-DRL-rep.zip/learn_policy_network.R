learn.policy.network=function(input.data,nepochs,a.pi,rate,len.i)
{
  model1 = keras_model_sequential() %>% 
    layer_dense(units=900, activation="relu", input_shape=len.i) %>% 
    layer_dense(units=400, activation = "relu") %>% 
    layer_dense(units=200, activation = "relu") %>% 
    layer_dense(units=100, activation = "relu") %>% 
    layer_dense(units=50, activation = "relu") %>% 
    layer_dense(units=29, activation="linear")
  
  data.s=scale(input.data)
  x<-as.matrix(data.s[,1:len.i])
  y<-as.matrix(data.s[,(len.i+1):(ncol(input.data)-1)])
  lr1=as.numeric(rate*a.pi)
  model1 %>% compile(
    loss = "mse",
    optimizer  = optimizer_sgd(lr =lr1), 
    #optimizer =  "adam",
    metrics = list("mean_absolute_error")
  )
  
  model1 %>% summary()
  
  model1 %>% fit(x, y, epochs = nepochs,verbose = 0)
  
  scores = model1 %>% evaluate(x, y, verbose = 0)
  print(scores)
  
  
  y_pred = model1 %>% predict(x)
  
  
  
  y.hat=y_pred * attr(data.s, 'scaled:scale')[(len.i+1):(ncol(data.s)-1)] + attr(data.s, 'scaled:center')[(len.i+1):(ncol(data.s)-1)]
  
  #y.true=unlist(input.data[,(len+1):(ncol(input.data)-1)])
  #y.hat1=unlist(as.data.frame(y.hat))
  #x_axes = seq(1:length(y.hat1))
  # plot(x_axes, y.hat1, type="l", col="red")
  #lines(x_axes,y.true , col="blue")
  par1=attr(data.s, 'scaled:scale')
  
  par2=attr(data.s, 'scaled:center')
  
  return(list(model1,par1,par2,  scores))
}

