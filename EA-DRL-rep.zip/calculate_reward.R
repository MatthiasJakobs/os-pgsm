
calculate.reward=function(error.vec)
{
  
  error.vec=as.numeric(error.vec)
  min.er=min(error.vec)
  
  max.er=max(error.vec)
  
  #error.vec[1]= min.er
  
  
  
  name.models=c('avg.ens',names(output.m)[2:30],'rf.ens')
  
  df=data.frame(name.models,error.vec)
  
  rank=rank(df$error.vec)
  
  df=cbind(df,rank)
  
  #reward1=-df$rank[nrow(df)]+df$rank[1]
  reward1=-df$rank[nrow(df)]+31
  
  if(reward1<0){reward1=0}
  
  
  reward2=-df$rank[nrow(df)]+df$rank[which(df$rank==min(df$rank))]
  
  #reward = 1-rmse(state[,1],state[,ncol(state)])/(max(state[,1])-min(state[,1]))
  #reward=c(length(error.vec)-rank(error.vec))[length(error.vec)]
  
  # if(error.vec[length(error.vec)]>max.er){reward=0}else if((error.vec[length(error.vec)]>error.vec[1])&(error.vec[length(error.vec)]<max.er))
  # {reward=1}else if((error.vec[length(error.vec)]==error.vec[1])&(error.vec[length(error.vec)]>min.er))
  # {reward=2}else if((error.vec[length(error.vec)]<error.vec[1])&(error.vec[length(error.vec)]>min.er))
  # {reward=3}else if(error.vec[length(error.vec)]<min.er){reward=5}else if((error.vec[length(error.vec)]==min.er))
  # {reward=5}else{reward=2}
  # 
  
  if(error.vec[length(error.vec)]>max.er){reward=0}else if((error.vec[length(error.vec)]>error.vec[1])&(error.vec[length(error.vec)]<max.er))
  {reward=0.2}else if((error.vec[length(error.vec)]==error.vec[1])&(error.vec[length(error.vec)]>min.er))
  {reward=0.5}else if((error.vec[length(error.vec)]<error.vec[1])&(error.vec[length(error.vec)]>min.er))
  {reward=0.8}else if(error.vec[length(error.vec)]<min.er){reward=1}else if((error.vec[length(error.vec)]==min.er))
  {reward=1}else{reward=0.5}
  
  
  
  return(c(reward,reward1,reward2))
  
}
