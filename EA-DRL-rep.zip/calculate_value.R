calculate.value=function(action,discount,l){
  
  state = construct.ensemble(action,output.m,l)
  
  error.ens=rmse(output.m[1:l,1],state)
  
  error.ens.s=sapply(1:l, function(y) rmse(output.m[y,1],state[y]))
  
  
  
  
  errors=sapply(2:ncol(output.m), function(x) rmse(output.m[1:l,1],output.m[1:l,x]))
  
  errors.s=sapply(1:l, function(y)sapply(2:ncol(output.m), function(x) rmse(output.m[y,1],output.m[y,x])))
  
  ens.avg=construct.ensemble(rep((1/(ncol(output.m)-1)),(ncol(output.m)-1)),output.m,l)
  
  #p=predict(ade, data.val)
  
  # ens.avg=p@y_hat[41:50]
  
  error.avg=rmse(output.m[1:l,1],ens.avg)
  
  error.avg.s=sapply(1:l, function(y) rmse(output.m[y,1], ens.avg[y]))
  error.vec=c(error.avg, errors,error.ens)
  
  error.vec.s=data.frame( error.avg.s,t(errors.s),error.ens.s)
  #to specify wich reward
  
  reward.vec=calculate.reward(error.vec)
  
  reward.vec.slist=lapply(1:l, function(y) calculate.reward(error.vec.s[y,]))
  
  
  reward.vec.s=sapply(1:l, function(y) reward.vec.slist[[y]][1])
  
  
  sum(reward.vec.s)
  
  return(reward.vec[2])
}