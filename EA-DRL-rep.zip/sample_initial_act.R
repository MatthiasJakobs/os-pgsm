sample.intial.action=function(output.m)
{
  a1 = dnorm(rnorm(ncol(output.m)-1))
  
  a1=a1/sum(a1)
  a2 <- sample(c(0,1), replace=TRUE, size=ncol(output.m)-1)
  
  pos=length(which(a2==1))
  a2=a2/pos
  repeat{ 
    a3 <- rbinom(ncol(output.m)-1, 1, 0.05)
    pos1=length(which(a3==1))
    
    if(pos1!=0){break}
    
  }
  
  
  pos1=length(which(a3==1))
  a3=a3/pos1
  
  indice=sample(1:3, 1)
  
  if(indice==1){a=a1}else if(indice==2){a=a2}else{a=a3}
  
  action=a
  
  
  
  
  return(action)
  
  
  
}