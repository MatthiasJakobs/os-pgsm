


source("../ensemble_and_data_prep.R")




H=10  #(\omega in the paper)

len=10

t=1

#models prediction tab
output.m=drift.topk.models.input(models,data.train, data.test,t,H, formula, per.arima,ker=c("rbfdot" ,"polydot" ,"vanilladot", "laplacedot"))



#sample initial actions
action=list(0)

reward=NULL
v=NULL
a.pi=NULL
pred=NULL

step=list(0)

state=list(0)

i=1
l=10
state.i=sapply(1:l, function(j) output.m[j,1])

H1=10


len.i=10


discount=0.9


#exploration phase 

repeat{ 
  
  
  action[[i]]=sample.intial.action(output.m)
  
  #reward[i]=0
  #ens.init=construct.ensemble(action,output.m,l)
  
  step[[i]]=step.cl(action[[i]],output.m,l)
  
  #pred[i]=step[[i]][[1]]
  
  state[[i]]=step[[i]][[1]]
  
  #specification of the reward
  reward[i]=step[[i]][[2]][2]
  
  v[i]=calculate.value(action[[i]],discount,l)
  
  #l=l+1
  i=i+1
  
  if(i>1000){break}
}



#seed(123)
th=17 #can be shifted to deversify sampling good and bad actions

pos1=which((reward>th))

pos11=which((sapply(1:length(pos1), function(x) reward[pos1[x]]- as.integer(reward[pos1[x]]))==0.5))

pos=which(reward<th)

pos2=sample(which(reward<21),min(length(pos11),length(pos)))


s=state[[pos2[1]]]

s.f=state[[pos1[1]]]

state.ini=list(0)

state.ini=state

#Initialize critic/value network

rate1=0.1
nepochs=1000
input.data=(lapply(c(pos1,pos2), function(i) (c(state[[i]],action[[i]],v[i]))))

input.data=do.call(rbind,input.data)

input.data=input.data[sample(1:nrow(input.data),nrow(input.data)),]

v.fit=learn.value.network(input.data,l,nepochs,rate1)



#Initialize policy network

a.pi[(i-2)]=reward[pos2[1]]+discount*value.predict(s.f,v.fit)-value.predict(s,v.fit)

#a.pi[(i-2)]=0+discount*value.predict(s.f,v.fit)-value.predict(s,v.fit)

a.pi
if(a.pi[(i-2)]<0){a.pi[(i-2)]=1}
a.pi.ini=a.pi[(i-2)]
rate=0.1
nepochs=1000

rate=10^(abs(floor(log10(abs(a.pi[i-2]))) +1))/10000

pi.fit=learn.policy.network(input.data,nepochs,a.pi[(i-2)],rate,len.i)




#input.data=t(as.data.frame(input.data[nrow(input.data),]))

#starting iterating episodes and iters
e=1

reward.e=list(0)

action.e=list(0)

v.e=list(0)

api.e=list(0)



#input.data=input.data.e
repeat{

if(e==1){k=k}else{  
  k=sample(pos1,1)}

action=list(0)

reward=NULL
v=NULL
a.pi=NULL
pred=NULL

step=list(0)

state=list(0)
a.pi.r=NULL

len=10
l=10
i=1
H1=10

h=10
nepochs=1000

ret1=NULL






repeat{
  
  
  if(i==1) {  #action[[i]]=rep((1/(ncol(output.m)-1)),(ncol(output.m)-1))
    
    
    
    #step[[(i)]]=step.cl(action[[i]],output.m,l)
    
    state[[(i)]]=s.f
    
    #state[[(i)]]=state.ini[[k]]
  }
  
  
  # s=sample(5:10,29,replace = T)/10
  
  action[[i]]=policy.predict( state[[(i)]],pi.fit,len.i)
  #action[[i]]=abs(action[[i]])/sum(abs(action[[i]]))
  
  # action[[i]]=(action[[i]]+s)/sum(action[[i]]+s)
  
  
  step[[(i)]]=step.cl(action[[i]],output.m,l)
  
  state[[(i+1)]]=step[[i]][[1]]
  
  reward[i]=step[[i]][[2]][2]
  
  
  v[i]=reward[i]+discount*value.predict( state[[(i+1)]],v.fit)
  #v[i]=+discount*value.predict( state[[(i+1)]],v.fit)
  
  # if((v[i]>v[(i-1)])|(reward[(i-1)]>reward[(i)])){v[i]=v[(i-1)]}
  #v[i]=calculate.value(action[[i]],discount,l)
  
  #if(i==1){input.data=rbind(input.data[(nrow(input.data)-20):nrow(input.data),], t(as.data.frame(c(state[[(i)]],action[[i]],v[i]))))
  #}else{
  input.data=rbind(input.data[sample(1:nrow(input.data),20),], t(as.data.frame(c(state[[(i)]],action[[i]],v[i]))))
  #}
  #input.data[,ncol(input.data)]=new.value
  
  v.fit=learn.value.network(input.data,len.i,nepochs,rate1)
  
  
  # a.pi[(i)]=reward[(i)]+discount*value.predict(state[[(i+1)]],v.fit)-v[i]
  
  a.pi[(i)]=reward[(i)]+discount*value.predict(state[[(i+1)]],v.fit)-value.predict(state[[(i)]],v.fit)
  
  
  #a.pi[(i)]=reward[(i)]+discount*input.data[nrow(input.data),31]-input.data[(nrow(input.data)-1),31]
  
  
  a.pi.r[(i)]=a.pi[(i)]
  a.pi.r
  # if(i>1){ 
  # if((a.pi[(i)]>a.pi[(i-1)])){a.pi[(i)]=a.pi[(i-1)]
  #         state[[(i+1)]]=state[[(i)]]
  #       }
  # }
  # 
  
  if(a.pi[i]<=0){
    
    if(i==1){a.pi[i]=1}else{
      
      pos=which(a.pi>0)
      a.pi[i]=a.pi[pos[length(pos)]]
      
    }}
  
  rate=10^(abs(floor(log10(abs(a.pi[i]))) +1))/10000
  
  pi.fit=learn.policy.network(input.data,nepochs, a.pi[(i)],rate,len.i)
  
  if( is.na(pi.fit[[4]][2])){ 
    if(a.pi[(i)]>1){pi.fit=learn.policy.network(input.data,nepochs, a.pi[(i)],rate/100,len.i)}else{
      pi.fit=learn.policy.network(input.data,nepochs, a.pi[(i)],rate/10,len.i)}
  }  
  
  print(paste('the iteration number', i, "with corresponding reward",reward[i], "and A.pi"
              ,a.pi[i], "and value",v[i]))
  
  i=i+1
  
  
  if(i>(100)){break}
  
}



reward.e[[e]]=reward

action.e[[e]]=action

v.e[[e]]=v

api.e[[e]]=a.pi


e=e+1

if(e>100){break}

}





