


construct.ensemble=function(action,output.m,l)
{
  
  #y.ens=sapply(1:l, function(j) sum(sapply(2:30, function(x) (action[(x-1)]*output.m[j,x]))))
  
  
  y.ens=sapply(1:l, function(y)  sum(sapply(2:30, function(x) (action[(x-1)]*output.m[y,x]))))
  # output.new=cbind(output.m,y.ens)
  
  return(y.ens)
  
}



step.cl=function(action,output.m,l){
  state = construct.ensemble(action,output.m,l)
  
  error.ens=rmse(output.m[1:l,1],state)
  
  error.ens.s=sapply(1:l, function(y) rmse(output.m[y,1],state[y]))
  
  
  
  
  errors=sapply(2:ncol(output.m), function(x) rmse(output.m[1:l,1],output.m[1:l,x]))
  
  errors.s=sapply(1:l, function(y)sapply(2:ncol(output.m), function(x) rmse(output.m[y,1],output.m[y,x])))
  
  ens.avg=construct.ensemble(rep((1/(ncol(output.m)-1)),(ncol(output.m)-1)),output.m,l)
  
  # p=predict(ade, data.val)
  
  #ens.avg=p@y_hat[41:50]
  
  error.avg=rmse(output.m[1:l,1],ens.avg)
  
  error.avg.s=sapply(1:l, function(y) rmse(output.m[y,1], ens.avg[y]))
  error.vec=c(error.avg, errors,error.ens)
  
  error.vec.s=data.frame( error.avg.s,t(errors.s),error.ens.s)
  min.er=min(error.vec)
  
  max.er=max(error.vec)
  
  # error.vec[1]= min.er
  
  
  name.models=c('avg.ens',names(output.m)[2:30],'rf.ens')
  
  df=data.frame(name.models,error.vec)
  
  rank=rank(df$error.vec)
  
  df=cbind(df,rank)
  
  #reward1=-df$rank[nrow(df)]+df$rank[1]
  reward1=-df$rank[nrow(df)]+31
  
  if(reward1<0){reward1=0}
  
  reward2=-df$rank[nrow(df)]+df$rank[which(df$rank==min(df$rank))]
  
  
  #reward = 1-rmse(state[,1],state[,ncol(state)])/(max(state[,1])-min(state[,1]))
  #reward=c(length(error.vec)-rank(error.vec))[length(error.vec)]
  
  # if(error.vec[length(error.vec)]>max.er){reward=-30}else if((error.vec[length(error.vec)]>error.vec[1])&(error.vec[length(error.vec)]<max.er))
  # {reward=-10}else if((error.vec[length(error.vec)]==error.vec[1])&(error.vec[length(error.vec)]>min.er))
  # {reward=0}else if((error.vec[length(error.vec)]<error.vec[1])&(error.vec[length(error.vec)]>min.er))
  # {reward=10}else if(error.vec[length(error.vec)]<min.er){reward=30}else if((error.vec[length(error.vec)]==min.er))
  # {reward=30}else{reward=0}
  
  
  # if(error.vec[length(error.vec)]>max.er){reward=0}else if((error.vec[length(error.vec)]>error.vec[1])&(error.vec[length(error.vec)]<max.er))
  # {reward=1}else if((error.vec[length(error.vec)]==error.vec[1])&(error.vec[length(error.vec)]>min.er))
  # {reward=2}else if((error.vec[length(error.vec)]<error.vec[1])&(error.vec[length(error.vec)]>min.er))
  # {reward=3}else if(error.vec[length(error.vec)]<min.er){reward=5}else if((error.vec[length(error.vec)]==min.er))
  # {reward=5}else{reward=2}
  
  if(error.vec[length(error.vec)]>max.er){reward=0}else if((error.vec[length(error.vec)]>error.vec[1])&(error.vec[length(error.vec)]<max.er))
  {reward=0.2}else if((error.vec[length(error.vec)]==error.vec[1])&(error.vec[length(error.vec)]>min.er))
  {reward=0.5}else if((error.vec[length(error.vec)]<error.vec[1])&(error.vec[length(error.vec)]>min.er))
  {reward=0.8}else if(error.vec[length(error.vec)]<min.er){reward=1}else if((error.vec[length(error.vec)]==min.er))
  {reward=1}else{reward=0.5}
  
  done = FALSE
  return(list(state, c(reward,reward1,reward2), action))
}


