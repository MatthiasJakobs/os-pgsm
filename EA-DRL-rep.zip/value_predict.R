value.predict=function(state.i,v.fit)
{
  par2=v.fit[[3]]
  
  par1=v.fit[[2]]
  
  #dd=v.fit[[3]]
  state.is=t(as.data.frame(sapply(1:length(state.i),
                                  function(x)  (state.i[x]-par2[x])/par1[x])))
  
  
  v_hat_s=v.fit[[1]] %>% predict_classes(state.is)
  
  
  #v.hat=dd[match(v_hat_s,dd[,2]), 1]
  
  v.hat=v_hat_s * v.fit[[2]][(ncol(state.is)+1)] +v.fit[[3]][(ncol(state.is)+1)]
  
  
  return( v.hat)
}
