

j=1
a1=list(0)

h=10 #(\omega in the paper)

max.ep=100

max.iter=100

#a1[[k]]=action[[30]]
pred=NULL

len.i=h=10
s=list(0)

repeat{  
  
  
  
  if(j==1){s[[j]]=state[[max.iter]] #last obtained state after finshing the 100 episode
  
  }
  
  a1[[(j)]]=policy.predict( s[[j]],pi.fit,len.i)
  
  pred[j]=sum((a1[[(j)]]*predictions.table[j,2:30]))
  
  s[[(j+1)]]=c(s[[j]][2:h],pred[j])
  
  
  
  j=j+1
  
  if(j>(nrow(predictions.table))){break}
}



real=predictions.table[,1]

rmse(real,pred)