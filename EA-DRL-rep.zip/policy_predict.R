policy.predict=function(state.i,pi.fit,len.i)
{ 
  par2=pi.fit[[3]]
  
  par1=pi.fit[[2]]
  
  #dd=v.fit[[4]]
  state.is=t(as.data.frame(sapply(1:length(state.i), 
                                  function(x)  (state.i[x]-par2[x])/par1[x])))
  
  
  ai.s=pi.fit[[1]] %>% predict(state.is)
  
  ai=ai.s * par1[(len.i+1):(length(par1)-1)] + par2[(len.i+1):(length(par2)-1)]
  
  ai=ai/sum(ai)
  return(ai)
}  
