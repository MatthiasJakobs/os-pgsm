learn.value.network=function(input.data,len.i,nepochs,rate1)
{
  
  
  data=(input.data[,c(1:len.i,ncol(input.data))])
  
  data.s=(scale(data))
  x<-(as.matrix((data.s)[,1:len.i]))
  y<-as.matrix(data.s[,ncol(data)])
  #y=to_categorical(as.numeric(as.factor(data[,ncol(data)])))
  
  model = keras_model_sequential() %>%
    layer_dense(units=64, activation="relu", input_shape=len.i) %>%
    layer_dense(units=32, activation = "relu") %>%
    layer_dense(units=16, activation = "relu") %>%
    layer_dense(units=ncol(y), activation="linear")
  
  
  #model %>% compile(
  # loss = "categorical_crossentropy",
  # optimizer  = optimizer_sgd(lr =rate1),
  # metrics = list("accuracy")
  # )
  
  
  model%>% compile(
    loss = "mse",
    #optimizer  = optimizer_sgd(lr =lr1),
    optimizer =  "adam",
    metrics = list("mean_absolute_error")
  )
  
  model %>% summary()
  
  model %>% fit(x, y, epochs = nepochs,verbose = 0)
  
  scores = model %>% evaluate(x, y, verbose = 0)
  print(scores)
  
  
  #y_pred = model %>% predict_classes(x)
  
  y_pred = model %>% predict(x)
  
  y.hat=y_pred * attr(data.s, 'scaled:scale')[ncol(data)] + attr(data.s, 'scaled:center')[ncol(data)]
  
  
  #t=table( as.factor(data[,ncol(data)]))
  
  #dd=data.frame(as.numeric(names(t)),c(1:length(t)))
  
  
  
  #y.hat=dd[match(y_pred,dd[,2]), 1]
  
  # y_pred = model %>% predict(x)
  y.true=unlist(data[,ncol(data)])
  x_axes = seq(1:length(y.hat))
  plot(x_axes, y.hat, type="l", col="red")
  lines(x_axes,y.true , col="blue")
  par1=attr(data.s, 'scaled:scale')
  
  par2=attr(data.s, 'scaled:center')
  
  return(list(model,par1,par2))
}

