
library(tensorflow)
library(reticulate)
system("virtualenv -p ../python  ../.virtualenvs/py3-virtualenv")

use_virtualenv("py3-virtualenv")

#install_tensorflow(envname = "py3-virtualenv")

install_tensorflow(gpu=TRUE,envname = "py3-virtualenv")



library(reinforcelearn)

library(keras)

library(tsensembler)