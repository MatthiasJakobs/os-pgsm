


library(otrimle)

library(rpart)
library(monmlp)
library(kernlab)
#libraries
library(tseries)
library("tsensembler")

library("forecast")


library(kernlab)


library(factoextra)

library(NbClust)

set.seed(123)


#mars
library("mda")


### gbm
library(gbm)

###rf
library(randomForest)


library(RSNNS)


#gp gaussian processes
library(kernlab)


#pls
## add ncomp to predict
library(pls)

library(opera)


library(Cubist)


library(glmnet)
#####
